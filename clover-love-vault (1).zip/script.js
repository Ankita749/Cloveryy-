
function showMessage() {
  const box = document.getElementById('messageBox');
  box.textContent = "You are the reason I believe in magic 💌 – Clove";
  box.classList.remove('hidden');
}
